<?php
require_once 'lib/db_login.php';// Include the database connection


//  TODO 5 : MENGAMBIL DATA DAFTAR CLASS DARI TABEL 'tb_classes' BERDASARKAN RACE YANG DIPILIH MENGGUNAKAN AJAX

// Check if the race parameter is set
if (isset($_GET['race'])) {
    $race = $_GET['race'];

    // Prepare and execute the SQL statement to fetch classes based on the race
    $stmt = $conn->prepare("SELECT class_name FROM tb_classes WHERE race = ?");
    $stmt->bind_param("s", $race);
    $stmt->execute();
    $result = $stmt->get_result();

    // Generate the HTML options for the class dropdown
    if ($result->num_rows > 0) {
        echo '<option value="">Select Class</option>'; // Default option
        while ($row = $result->fetch_assoc()) {
            echo '<option value="' . $row['class_name'] . '">' . $row['class_name'] . '</option>';
        }
    } else {
        echo '<option value="">No classes available</option>'; // If no classes are found for the race
    }

    // Close the statement
    $stmt->close();
} else {
    echo '<option value="">Select a race first</option>';
}
?>
