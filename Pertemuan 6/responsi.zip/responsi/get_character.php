//  TODO 4 : MENGAMBIL DATA USER DARI TABEL 'tb_characters' DENGAN PARAMETER EMAIL
<?php
require_once 'lib/db_login.php';

// Function to get user by email
function getCharacterByEmail($email)
{
    global $conn; // Use the existing database connection

    // Prepare and bind SQL statement to avoid SQL injection
    $stmt = $conn->prepare("SELECT * FROM tb_characters WHERE email = ?");
    $stmt->bind_param("s", $email);
    
    // Execute the query
    $stmt->execute();
    
    // Get the result
    $result = $stmt->get_result();
    
    // Check if a user was found
    if ($result->num_rows > 0) {
        // Fetch the user's data
        return $result->fetch_assoc();
    } else {
        return null; // No user found
    }

    // Close the statement
    $stmt->close();
}

// Example of using the function
if (isset($_GET['email'])) {
    $email = $_GET['email'];
    $character = getCharacterByEmail($email);

    if ($character) {
        // User found, display their data (you can adjust the display format)
        echo "Character found: <br>";
        echo "Name: " . $character['name'] . "<br>";
        echo "Race: " . $character['race'] . "<br>";
        echo "Class: " . $character['class'] . "<br>";
        echo "Attributes: " . $character['attributes'] . "<br>";
        echo "Skills: " . $character['skills'] . "<br>";
    } else {
        echo "Character not found with email: $email";
    }
}
?>
