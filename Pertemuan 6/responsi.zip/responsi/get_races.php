<?php
require_once 'lib/db_login.php'; // Include the database connection

//  TODO 5 : MENGAMBIL DATA DAFTAR RACE DARI TABEL 'tb_races'

// Function to get the list of races from the database
function getRaces() {
    global $conn; // Use the existing database connection

    // Query to retrieve all races from the 'tb_races' table
    $sql = "SELECT race_name FROM tb_races";
    $result = $conn->query($sql);

    // Check if any races were found
    if ($result->num_rows > 0) {
        // Fetch each race and generate an HTML option
        while ($row = $result->fetch_assoc()) {
            echo '<option value="' . $row['race_name'] . '">' . $row['race_name'] . '</option>';
        }
    } else {
        echo '<option value="">No races available</option>';
    }
}
?>
