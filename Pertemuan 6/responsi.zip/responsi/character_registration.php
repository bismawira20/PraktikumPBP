<?php
include('header.html');
require_once 'lib/db_login.php';

/*
  TODO 2 : BUATLAH
  1. server side validation
  2. insert new character
  3. tampilan hasilnya error / berhasil
*/

if (isset($_POST['submit'])) {
    $valid = TRUE;
    $error_msg = '';

    // Player Name Validation
    $player_name = test_input($_POST['player_name']);
    if (!preg_match("/^[a-zA-Z ]*$/", $player_name)) {
        $valid = FALSE;
        $error_player_name .= "Player Name can only contain letters and spaces.<br>";
    }elseif (empty($player_name))  {
        $valid = FALSE;
        $error_player_name = "Player Name is required.<br>";
    }


    // Email Validation
    $email = test_input($_POST['email']);
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $valid = FALSE;
        $error_Email = "Valid email is required.<br>";
    }elseif (empty($email)) {
        $valid = FALSE;
        $error_Email = "Valid email is required.<br>";
    }

    // Password Validation
    $password = test_input($_POST['password']);
    if (!strlen($password) < 8) {
        $valid = FALSE;
        $error_PW = "Password must be at least 8 characters long.<br>";
    }elseif (empty($password)) {
        $valid = FALSE;
        $error_PW = "Password must be at least 8 characters long.<br>";
    }


    // Race Validation
    $race = test_input($_POST['race']);
    if (empty($race)) {
        $valid = FALSE;
        $error_Race = "Race is required.<br>";
    }

    // Class Validation
    $class = test_input($_POST['class']);
    if (empty($class)) {
        $valid = FALSE;
        $error_Class = "Class is required.<br>";
    }

    // Attributes Validation
    $strength = (int) $_POST['strength'];
    $agility = (int) $_POST['agility'];
    $intelligence = (int) $_POST['intelligence'];
    if ($strength + $agility + $intelligence != 100) {
        $valid = FALSE;
        $error_Attribute = "Total attributes must equal 100.<br>";
    }

    // Skills Validation
    $skills = $_POST['skills'];
    if (empty($skills)) {
        $valid = FALSE;
        $error_Skill = "At least one skill must be selected.<br>";
    }

    if ($valid) {
        // Hash the password
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        
        // Insert into database
        $skills_str = implode(",", $skills);
        $sql = "INSERT INTO tb_characters (name, email, password, race, class, attributes, skills)
                VALUES ('$player_name', '$email', '$hashed_password', '$race', '$class', 
                        'Strength: $strength, Agility: $agility, Intelligence: $intelligence', '$skills_str')";
        
        if ($conn->query($sql) === TRUE) {
            echo "<div class='alert alert-success'>Character created successfully!</div>";
        } else {
            echo "<div class='alert alert-danger'>Error: " . $conn->error . "</div>";
        }
    } else {
        echo "<div class='alert alert-danger'>$error_msg</div>";
    }
}
?>

<div class="card">
    <div class="card-header text-center">
        <h3>RPG Character Registration</h3>
    </div>
    <div class="card-body">
        <!-- TODO 3 : DEFINISIKAN METHOD DAN ACTIONS YANG SESUAI -->
        <form name="regist" method="POST" action="">
            <!-- Player Name -->
            <div class="form-group">
                <label for="player_name">Player Name</label>
                <input type="text" name="player_name" id="player_name" class="form-control" value="<?php echo isset($_POST['player_name']) ? $_POST['player_name'] : ''; ?>">
                <div class="text-danger">
                    <!-- ERROR MSG -->
                    <?php if(isset($error_player_name)) echo $error_player_name;?>
                </div>
            </div>
            
            <!-- Email -->
            <!-- TODO 4 : BUATLAH CEK EMAIL MENGGUNAKAN AJAX -->
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" name="email" id="email" class="form-control" value="<?php echo isset($_POST['email']) ? $_POST['email'] : ''; ?>">
                <div class="text-danger" id="error_email">
                    <!-- ERROR MSG -->
                    <?php if(isset($error_Email)) echo $error_Email;?>
                </div>
            </div>

            <!-- Password -->
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" name="password" id="password" class="form-control">
                <div class="text-danger">
                    <!-- ERROR MSG -->
                    <?php if(isset($error_PW)) echo $error_PW;?>
                </div>
            </div>

            <!-- Race and Class -->
            <!-- TODO 5 : TAMPILKAN DAFTAR CLASS BERDASARKAN PILIHAN RACE YANG DIPILIH MENGGUNAKAN AJAX -->
            <div class="form-group">
                <label for="race">Race</label>
                <select name="race" id="race" class="form-control">
                    <option value="">Select Race</option>
                    <!-- Add options dynamically -->
                </select>
                <div class="text-danger" id="error_race">
                    <!-- ERROR MSG -->
                    <?php if(isset($error_Race)) echo $error_Race;?>
                </div>
            </div>
            <div class="form-group">
                <label for="class">Class</label>
                <select name="class" id="class" class="form-control">
                    <option value="">Select Class</option>
                </select>
                <div class="text-danger" id="error_class">
                    <!-- ERROR MSG -->
                    <?php if(isset($error_Class)) echo $error_Class;?>
                </div>
            </div>

            <!-- Attributes (Strength, Agility, Intelligence) -->
            <div class="form-group">
                <label for="attributes">Character Attributes (Total: 100)</label>
                <div class="d-flex justify-content-between">
                    <div class="p-2 flex-grow-1">
                        <label for="strength">Strength: </label>
                        <input type="number" name="strength" id="strength" class="form-control" min="0" max="100">
                    </div>
                    <div class="p-2 flex-grow-1">
                        <label for="agility">Agility: </label>
                        <input type="number" name="agility" id="agility" class="form-control" min="0" max="100">
                    </div>
                    <div class="p-2 flex-grow-1">
                        <label for="intelligence">Intelligence: </label>
                        <input type="number" name="intelligence" id="intelligence" class="form-control" min="0" max="100">
                    </div>
                </div>
                <div class="text-danger">
                    <!-- ERROR MSG -->
                    <?php if(isset($error_Attribute)) echo $error_Attribute;?>
                </div>
            </div>

            <!-- Skills -->
            <div class="form-group">
                <label for="skills">Select Skills (Ctrl + Click for multiple)</label>
                <select name="skills[]" id="skills" class="form-control" multiple>
                    <option value="Swordsmanship">Swordsmanship</option>
                    <option value="Archery">Archery</option>
                    <option value="Magic">Magic</option>
                    <option value="Stealth">Stealth</option>
                </select>
                <div class="text-danger">
                    <!-- ERROR MSG -->
                    <?php if(isset($error_Skill)) echo $error_Skill;?>
                </div>
            </div>
            <br>
            <button type="submit" name="submit" class="btn btn-primary btn-block">Create Character</button>
        </form>
    </div>
</div>

<?php include('footer.html') ?>
