function getXMLHttpRequest() {
    if (window.XMLHttpRequest) {
        //code for modern browser
        return new XMLHttpRequest();
    } else {
        //code for old IE browser
        return new ActiveXObject("Microsoft.XMLHTTP");
    }
}

// TODO 4 : LENGKAPI FUNCTION UNTUK CEK EMAIL MENGGUNAKAN AJAX
function getCharacter() {
    var email = document.getElementById("email").value;
    
    if (email === "") {
        document.getElementById("error_email").innerHTML = "Email cannot be empty.";
        return;
    }

    var xhr = getXMLHttpRequest(); // Get the XMLHttpRequest object
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
            // Handle the response from the server
            document.getElementById("error_email").innerHTML = xhr.responseText;
        }
    };
    
    // Send the request to the server with the email as a parameter
    xhr.open("GET", "check_email.php?email=" + email, true);
    xhr.send();
}


// TODO 5 : LENGKAPI FUNCTION UNTUK MENDAPATKAN DAFTAR CLASS BERDASARKAN PILIHAN RACE MENGGUNAKAN AJAX
function getClasses(race) {
    if (race === "") {
        document.getElementById("class").innerHTML = '<option value="">Select Class</option>';
        return;
    }

    var xhr = getXMLHttpRequest(); // Get the XMLHttpRequest object
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
            // Update the class dropdown with the response data
            document.getElementById("class").innerHTML = xhr.responseText;
        }
    };

    // Send the request to the server with the race as a parameter
    xhr.open("GET", "get_classes.php?race=" + race, true);
    xhr.send();
}

